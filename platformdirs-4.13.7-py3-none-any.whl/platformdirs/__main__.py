"""Main entry point."""

from __future__ import annotations

from typing import TYPE_CHECKING

from platformdirs import PlatformDirs, __version__

if TYPE_CHECKING:
    from platformdirs.api import PlatformDirsABC

PROPS = (
    "user_data_dir",
    "user_config_dir",
    "user_cache_dir",
    "user_state_dir",
    "user_log_dir",
    "user_documents_dir",
    "user_downloads_dir",
    "user_pictures_dir",
    "user_videos_dir",
    "user_music_dir",
    "user_desktop_dir",
    "user_projects_dir",
    "user_publicshare_dir",
    "user_templates_dir",
    "user_fonts_dir",
    "user_preference_dir",
    "user_bin_dir",
    "site_bin_dir",
    "user_applications_dir",
    "user_runtime_dir",
    "site_data_dir",
    "site_config_dir",
    "site_cache_dir",
    "site_state_dir",
    "site_log_dir",
    "site_applications_dir",
    "site_runtime_dir",
)


def main() -> None:
    """Run the main entry point."""
    app_name = "MyApp"
    app_author = "MyCompany"

    print(f"-- platformdirs {__version__} --")  # ruff:ignore[print]

    print("-- app dirs (with optional 'version')")  # ruff:ignore[print]
    _print_dirs(PlatformDirs(app_name, app_author, version="1.0"))

    print("\n-- app dirs (without optional 'version')")  # ruff:ignore[print]
    _print_dirs(PlatformDirs(app_name, app_author))

    print("\n-- app dirs (without optional 'appauthor')")  # ruff:ignore[print]
    _print_dirs(PlatformDirs(app_name))

    print("\n-- app dirs (with disabled 'appauthor')")  # ruff:ignore[print]
    _print_dirs(PlatformDirs(app_name, appauthor=False))


def _print_dirs(dirs: PlatformDirsABC) -> None:
    for prop in PROPS:
        print(f"{prop}: {_dir_or_error(dirs, prop)}")  # ruff:ignore[print]


def _dir_or_error(dirs: PlatformDirsABC, prop: str) -> str:
    # A missing home or an unusable runtime directory should not stop the diagnostic report.
    try:
        return getattr(dirs, prop)
    except (PermissionError, RuntimeError) as error:
        return str(error)


if __name__ == "__main__":
    main()
